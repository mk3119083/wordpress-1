
  <?php
   		register_nav_menus(
			array('top-menu'=>'Top Menu','footer-menu'=>'Footer Menu')
		)
		
		?>


